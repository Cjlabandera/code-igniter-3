<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Custom Styles */
        body {
            background-color: #f8f9fa; /* Light background color */
            font-family: Arial, sans-serif; /* Custom font */
        }

        .container {
            max-width: 600px; /* Limit container width */
            margin-top: 50px; /* Space above container */
            background-color: #ffffff; /* White background for the form */
            border-radius: 8px; /* Rounded corners */
            padding: 20px; /* Padding inside the container */
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1); /* Subtle shadow */
        }

        h1 {
            text-align: center; /* Center the heading */
            color: #343a40; /* Dark text color */
            margin-bottom: 20px; /* Space below heading */
        }

        .btn {
            width: 100%; /* Full width buttons */
            margin-top: 10px; /* Space above buttons */
        }

        @media (max-width: 576px) {
            h1 {
                font-size: 1.5rem; /* Responsive heading size */
            }
        }
    </style>
</head>
<body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
    <div class="container mt-5">
        <h1>Edit User</h1>
        <form action="<?php echo base_url(); ?>index.php/auth/update_user/<?= $user->user_id ?>" method="POST">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" name="username" class="form-control" value="<?= $user->username ?>" required>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" class="form-control" value="<?= $user->email ?>" required>
            </div>

            <div class="mb-3">
                <label for="birthday" class="form-label">Birthday</label>
                <input type="date" name="birthday" class="form-control" value="<?= $user->birthday ?>" required>
            </div>

            <div class="mb-3">
                <label for="phone" class="form-label">Phone</label>
                <input type="text" name="phone" class="form-control" value="<?= $user->phone ?>" required>
            </div>

            <button type="submit" class="btn btn-success">Update</button>
            <a href="<?php echo base_url(); ?>index.php/auth/displaylist" class="btn btn-secondary">Cancel</a>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
