
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Profile Page</title>
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
                                                                         
    <div class="col-lg-4 col-lg-offset-2">
    <h1>Welcome to Rust Server</h1>
    <p></p>
            <?php if(isset($_SESSION['success']))
            {?>

                    <div class="alert alert-success"><?php echo $_SESSION['success']?></div>

                    <?php


                }?>


                    Hello Welcome to Rust Server, <?php echo $_SESSION['username']; ?> 

                    <br><br>
                    <a href="<?php echo base_url(); ?>index.php/auth/logout">Logout</a>
                       
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
  </body>
</html>