<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>List of Users Page</title>
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Custom Styles */
    /* Custom Styles */
body {
    background-color: #e9ecef; /* Light grey background */
}

.container {
    margin-top: 30px; /* Space above the container */
}

h1 {
    margin-bottom: 20px; /* Space below the heading */
    text-align: center; /* Center the heading */
    color: #343a40; /* Darker text color */
}

.table {
    background-color: #ffffff; /* White background for the table */
    border-radius: 8px; /* Rounded corners */
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Subtle shadow effect */
}

.table th, .table td {
    vertical-align: middle; /* Align content vertically */
    padding: 12px; /* Padding for cells */
    text-align: center; /* Center align text for all cells */
    font-size: 14px; /* Base font size */
    word-wrap: break-word; /* Allows long words to break */
}

.table thead {
    background-color: #007bff; /* Bootstrap primary color for header */
    color: #ffffff; /* White text for header */
}

.btn-edit, .btn-delete {
    padding: 0.375rem 0.75rem; /* Adjust button padding */
    border-radius: 0.25rem; /* Rounded button corners */
}

.actions {
    display: flex; /* Use flexbox for actions */
    gap: 5px; /* Space between buttons */
    justify-content: center; /* Center buttons in the actions column */
}

.btn-primary {
    background-color: #28a745; /* Green color for edit */
    border: none; /* Remove border */
}

.btn-danger {
    background-color: #dc3545; /* Red color for delete */
    border: none; /* Remove border */
}

@media (max-width: 768px) {
    .table-responsive {
        overflow-x: auto; /* Enable horizontal scrolling for smaller screens */
    }

    .table th, .table td {
        font-size: 12px; /* Smaller font size for small screens */
        padding: 8px; /* Reduced padding for smaller screens */
    }

    .btn {
        width: 100%; /* Full-width buttons on small screens */
    }
}

/* Optional: Add ellipsis for overflowing text */
.table td {
    overflow: hidden; /* Hide overflow */
    white-space: nowrap; /* Prevent line breaks */
    text-overflow: ellipsis; /* Add ellipsis (...) */
}

    </style>
</head>
<body>
    <div class="container">
        <div class="col-lg-10 col-lg-offset-1">
            
        <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success"><?php echo $_SESSION['success']; ?></div>
            <?php endif; ?>
            
            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-danger"><?php echo $_SESSION['error']; ?></div>
            <?php endif; ?>
            <h1>List of Users</h1>

            <div class="table-responsive"> <!-- Add responsive wrapper -->
                <table class="table table-bordered table-hover"> <!-- Add Bootstrap classes for borders and hover effect -->
                    <thead>
                        <tr>
            
                            <th scope="col">Username</th>
                            <th scope="col">Email</th>
                            <th scope="col">Birth Day</th>
                            <th scope="col">Age</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Date Created</th>
                            <th scope="col">Phone</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                                                <tbody>
                                <?php foreach ($users as $row): ?>
                                    <tr>
                                       
                                        <td><?= $row->username ?></td>
                                        <td><?= $row->email ?></td>
                                        <td><?= $row->birthday ?></td>
                                        <td><?= $row->age ?></td> <!-- Displaying calculated age here -->
                                        <td><?= $row->gender ?></td>
                                        <td><?= $row->created_date ?></td>
                                        <td><?= $row->phone ?></td>
                                        <td class="actions">
                                            <a href="<?= base_url(); ?>index.php/auth/edit_user/<?= $row->user_id; ?>" class="btn btn-primary btn-edit">Edit</a>
                                            <a href="<?= base_url(); ?>index.php/auth/delete_user/<?= $row->user_id; ?>" class="btn btn-danger btn-delete" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
                                        </td>

                                    </tr>
                                <?php endforeach; ?>
                            </tbody>

                </table>
            </div>

            <div class="text-center">
                <a href="<?php echo base_url(); ?>index.php/auth/logout" class="btn btn-secondary mt-3">Back to Login Page</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
</body>
</html>
