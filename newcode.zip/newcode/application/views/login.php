<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Page</title>
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('<?php echo base_url(); ?>assets/images/rust.gif'); /* Add your image path */
            background-size: cover; /* Cover the entire page */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent image repetition */
            background-attachment: fixed; /* Fix the background image when scrolling */
            font-family: 'Arial', sans-serif;
        }

        .col-lg-4 {
            margin: 80px auto; /* Center the login box */
            padding: 30px; /* Padding inside the box */
            background-color: rgba(255, 255, 255, 0.8); /* Semi-transparent white */
            border-radius: 10px; /* Rounded corners */
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); /* Subtle shadow */
        }

        h1 {
            font-size: 2rem; /* Heading size */
            color: #343a40; /* Dark color for heading */
            text-align: center; /* Center the heading */
            margin-bottom: 20px; /* Space below heading */
        }

        .form-floating {
            margin-bottom: 20px; /* Space between form fields */
        }

        .form-control {
            border-radius: 6px; /* Rounded input fields */
        }

        .btn-primary {
            width: 100%; /* Full width button */
            padding: 10px; /* Padding for button */
            font-size: 1.1rem; /* Button text size */
            background-color: #007bff; /* Button color */
            border: none; /* Remove border */
            border-radius: 6px; /* Rounded button corners */
            transition: background-color 0.3s ease; /* Smooth color transition */
        }

        .btn-primary:hover {
            background-color: #0056b3; /* Darker button color on hover */
        }

        a {
            text-decoration: none; /* Remove underline */
            color: #007bff; /* Link color */
        }

        a:hover {
            text-decoration: underline; /* Underline on hover */
            color: #0056b3; /* Darker link color */
        }

        .alert-success {
            background-color: #d4edda; /* Green background for success */
            color: #155724; /* Dark green text */
            border-color: #c3e6cb; /* Border color */
            margin-top: 10px; /* Space above alert */
        }

        .alert-danger {
            background-color: #f8d7da; /* Red background for danger */
            color: #721c24; /* Dark red text */
            border-color: #f5c6cb; /* Border color */
            margin-top: 10px; /* Space above alert */
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .col-lg-4 {
                margin: 20px; /* Less margin on smaller screens */
                padding: 20px; /* Less padding */
            }

            h1 {
                font-size: 1.8rem; /* Smaller heading size */
            }

            .btn-primary {
                font-size: 1rem; /* Smaller button text */
            }
        }

        @media (max-width: 576px) {
            h1 {
                font-size: 1.5rem; /* Further reduce heading size */
            }

            .btn-primary {
                padding: 8px; /* Smaller padding */
            }

            a {
                font-size: 0.9rem; /* Smaller link text */
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="col-lg-4 col-lg-offset-2">
            <h1>Welcome to Rust Server</h1>
            <p>Fill in the details to Login on our website!!</p>

            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success"><?php echo $_SESSION['success']; ?></div>
            <?php endif; ?>
            
            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-danger"><?php echo $_SESSION['error']; ?></div>
            <?php endif; ?>
            
            <?php echo validation_errors('<div class="alert alert-danger">', '</div>'); ?>

            <form action="" method="POST">
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" name="username" id="username" placeholder="name@example.com" required>
                    <label for="username">Username</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
                    <label for="password">Password</label>
                </div>
                <div>
                    <button class="btn btn-primary" name="login">Login</button>
                </div>
            </form>

            <div class="mt-3">
                <a href="<?php echo base_url(); ?>index.php/auth/register">Create new account!</a>
            </div>
            <div class="mt-2">
                <a href="<?php echo base_url(); ?>index.php/auth/displaylist">Registered User!</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
</body>
</html>
