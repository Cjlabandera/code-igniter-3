<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register Page</title>
    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <style>
      /* Custom CSS goes here */

      body {
          background-color: #f8f9fa; /* Light background color */
          font-family: 'Arial', sans-serif; /* Font style */
      }

      .col-lg-4 {
          margin: 50px auto; /* Center the registration box */
          padding: 20px; /* Padding inside the box */
          background-color: #ffffff; /* White background for form */
          border-radius: 8px; /* Rounded corners */
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow */
      }

      .btn-primary {
          background-color: #007bff; /* Button color */
          border-color: #007bff; /* Border color */
          transition: background-color 0.3s ease; /* Smooth color transition */
      }

      .btn-primary:hover {
          background-color: #0056b3; /* Darker button color on hover */
          border-color: #004085; /* Darker border on hover */
      }

      h1 {
          font-size: 2rem; /* Heading size */
          margin-bottom: 20px; /* Space below heading */
          color: #343a40; /* Dark color for heading */
      }

      a {
          text-decoration: none; /* Remove underline from links */
          color: #007bff; /* Link color */
      }

      a:hover {
          text-decoration: underline; /* Underline on hover */
          color: #0056b3; /* Darker link color */
      }

      .alert-success {
          background-color: #d4edda; /* Green background for success messages */
          color: #155724; /* Dark green text */
          border-color: #c3e6cb; /* Border color */
      }

      .alert-danger {
          background-color: #f8d7da; /* Red background for danger messages */
          color: #721c24; /* Dark red text */
          border-color: #f5c6cb; /* Border color */
      }

      /* Responsive Styles */
      @media (max-width: 768px) {
          .col-lg-4 {
              margin: 20px; /* Less margin on smaller screens */
              padding: 15px; /* Less padding */
          }

          h1 {
              font-size: 1.8rem; /* Smaller heading size */
          }
      }

      @media (max-width: 576px) {
          h1 {
              font-size: 1.5rem; /* Further reduce heading size */
          }

          .btn-primary {
              font-size: 1rem; /* Smaller button text */
              padding: 10px; /* Smaller button padding */
          }

          a {
              font-size: 0.9rem; /* Smaller link text */
          }
      }
    </style>
  </head>
  <body>
    <div class="col-lg-4 col-lg-offset-2">
      <h1>Register Page</h1>
      <p>Fill in the details to Register on our website!</p>

      <?php if(isset($_SESSION['success'])): ?>
          <div class="alert alert-success"><?php echo $_SESSION['success']; ?></div>
      <?php endif; ?>
      
      <?php echo validation_errors('<div class="alert alert-danger">', '</div>'); ?>

      <form action="" method="POST">
          <div class="form-floating mb-3">
              <input type="text" class="form-control" name="username" id="username" placeholder="name@example.com" required>
              <label for="username">Username</label>
          </div>
          <div class="form-floating mb-3">
              <input type="email" class="form-control" name="email" id="email" placeholder="name@example.com" required>
              <label for="email">Email</label>
          </div>
          <div class="form-floating mb-3">
              <input type="date" class="form-control" name="birthday" id="birthday" required>
              <label for="birthday">Birthday</label>
          </div>
          <div class="form-floating mb-3">
              <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
              <label for="password">Password</label>
          </div>
          <div class="form-floating mb-3">
              <input type="password" class="form-control" name="password2" id="password2" placeholder="Confirm Password" required>
              <label for="password2">Confirm Password</label>
          </div>
          <div class="form-floating mb-3">
              <select name="gender" id="gender" class="form-select" required>
                  <option selected disabled value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
              </select>
              <label for="gender">Gender:</label>
          </div>
          <div class="form-floating mb-3">
              <input type="text" class="form-control" name="phone" id="phone" placeholder="Phone Number" required>
              <label for="phone">Phone Number</label>
          </div>
          <div>
              <button class="btn btn-primary" name="register">Register</button>
          </div>
      </form>
      <div>
          <a href="<?php echo base_url(); ?>index.php/auth/login">Already have an account!</a>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
  </body>
</html>
