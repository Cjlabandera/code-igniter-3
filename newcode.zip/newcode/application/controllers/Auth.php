<?php


class Auth extends CI_Controller
{
    public function index(){
         $this->load->view('login');

    }


    //for logout 
    
        public function logout()
        {
            unset($_SESSION);
            session_destroy();
            redirect("auth/login", "refresh");
        }

        

    //for login

        public function login()
        {

            $this->form_validation->set_rules('username', 'Username', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required');

            if($this->form_validation->run() == TRUE)
            {

                $username = $_POST['username'];
                $password = md5($_POST['password']);

                //check user in database
                $this->db->select('*');
                $this->db->from('users');
                $this->db->where(array('username' => $username, 'password' => $password));
                $query = $this->db->get();


                $user = $query->row();
                //if user exist
                if($user->email)
                {
                    //temporary message
                    $this->session->set_flashdata("success", "You are Logged in");

                    //set session var

                    $_SESSION['user_logged'] = TRUE;
                    $_SESSION['username'] = $user->username;

                    //redirect to profile page
                    
                    redirect("user/profile", "refresh");

                }else{
                    $this->session->set_flashdata("error", "No such account exist in database");
                    redirect("auth/login");
                }



            }



            $this->load->view('login');



        }
       //for register
        public function register()
        {



            if(isset($_POST['register']))
            {
                $this->form_validation->set_rules('username', 'Username', 'required');
                $this->form_validation->set_rules('email', 'Email', 'required');
                $this->form_validation->set_rules('birthday', 'Birthday', 'required');
                $this->form_validation->set_rules('password', 'Password', 'required|min_length[8]');
                $this->form_validation->set_rules('password2', 'Confirm Password', 'required|min_length[8]|matches[password]');
                $this->form_validation->set_rules('phone', 'Phone', 'required|min_length[11]');
                //if form validation is true
                if($this->form_validation->run() == TRUE)
                {
                    echo 'form validated';

                    //add user in database
                    

                    $data = array('username'=>$_POST['username'], 
                                'email'=>$_POST['email'], 'birthday'=>$_POST['birthday'],
                                'password'=>md5($_POST['password']), 
                                'gender'=>$_POST['gender'], 
                                'created_date'=>date('Y,m,d'), 
                                'phone'=>$_POST['phone']);

                    $this->db->insert('users', $data );
                    $this->session->set_flashdata("success", "Your Account has been registered. You can login now");
                    redirect("auth/login", "refresh");

                }
            }


            //load view


                        $this->load->view('register');
        }

        //for display

        public function displaylist()
        {
            $this->load->model("Auth_model");
            $users = $this->Auth_model->getRegisterUsers();
    
            // Calculate age for each user based on birthday
            foreach ($users as &$user) {
                $user->age = $this->calculate_age($user->birthday); // Use helper function
            }
    
            // Pass updated users data to view
            $data['users'] = $users;
            $this->load->view('displaylist', $data);
        }
    
        // Helper function to calculate age based on birthday
        private function calculate_age($birthday)
        {
            $birthDate = new DateTime($birthday);  // Convert string birthday to DateTime object
            $today = new DateTime();               // Get today's date
            return $today->diff($birthDate)->y;    // Calculate the age (years)
        }

     // edite users

     public function edit_user($user_id)
     {
         $this->load->model('Auth_model');
         $data['user'] = $this->Auth_model->getUserById($user_id);
 
         $this->load->view('edit_user', $data);
     }
 
     public function update_user($user_id)
     {
         $this->form_validation->set_rules('username', 'Username', 'required');
         $this->form_validation->set_rules('email', 'Email', 'required');
         $this->form_validation->set_rules('birthday', 'Birthday', 'required');
         $this->form_validation->set_rules('phone', 'Phone', 'required');
 
         if ($this->form_validation->run() == TRUE) {
             $data = array(
                 'username' => $this->input->post('username'),
                 'email' => $this->input->post('email'),
                 'birthday' => $this->input->post('birthday'),
                 'phone' => $this->input->post('phone')
             );
 
             $this->load->model('Auth_model');
             $update = $this->Auth_model->updateUser($user_id, $data);
 
             if ($update) {
                 $this->session->set_flashdata("success", "User updated successfully");
             } else {
                 $this->session->set_flashdata("error", "Failed to update user");
             }
 
             redirect('auth/displaylist');
         } else {
             $this->edit_user($user_id); // Reload form with errors
         }
     }
     // delete users 
     public function delete_user($user_id)
{
    // Load the model
    $this->load->model('Auth_model');
    
    // Attempt to delete the user
    $delete = $this->Auth_model->deleteUser($user_id);
    
    if ($delete) {
        $this->session->set_flashdata("success", "User deleted successfully");
    } else {
        $this->session->set_flashdata("error", "Failed to delete user");
    }
    
    redirect('auth/displaylist'); // Redirect back to the user list
}


     
}