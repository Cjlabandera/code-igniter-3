<?php

 



                            class Auth_model extends CI_Model
                            {
                                public function __construct()
                                {
                                    parent::__construct();
                                    
                                }

                                public function getRegisterUsers()
                                {
                                    $query = $this->db->get('users');
                                    return $query->result();
                                }
                                 public function getUserById($user_id)
                                {
                                    $query = $this->db->get_where('users', array('user_id' => $user_id));
                                    return $query->row();
                                }

                                public function updateUser($user_id, $data)
                                {
                                    $this->db->where('user_id', $user_id);
                                    return $this->db->update('users', $data);
                                }
                                public function deleteUser($user_id)
                                {
                                    $this->db->where('user_id', $user_id);
                                    return $this->db->delete('users');
                                }


                                
                            }